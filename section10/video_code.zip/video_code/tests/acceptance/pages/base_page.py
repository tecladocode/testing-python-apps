class BasePage:
    pass


class BaseLocators:
    pass

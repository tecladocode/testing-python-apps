from section6.video_code.tests.acceptance.pages.base_page import BasePage


class PostPage(BasePage):
    pass
